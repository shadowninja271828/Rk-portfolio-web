---
name: Obsidian Lumina
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#bacac7'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#859491'
  outline-variant: '#3b4a47'
  surface-tint: '#34dccf'
  primary: '#49e9dc'
  on-primary: '#003733'
  primary-container: '#0dcdc0'
  on-primary-container: '#00524c'
  inverse-primary: '#006a63'
  secondary: '#bdc8d3'
  on-secondary: '#28313b'
  secondary-container: '#3e4852'
  on-secondary-container: '#acb6c2'
  tertiary: '#bad5ff'
  on-tertiary: '#00315d'
  tertiary-container: '#88baff'
  on-tertiary-container: '#004986'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#5df9eb'
  primary-fixed-dim: '#34dccf'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#dae3f0'
  secondary-fixed-dim: '#bdc8d3'
  on-secondary-fixed: '#131d25'
  on-secondary-fixed-variant: '#3e4852'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '600'
    lineHeight: 76px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  body-xl:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '300'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.15em
  label-numeric:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 2rem
  gutter-sm: 1rem
  margin: 4rem
  margin-sm: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system channels the refined precision, power, and sensual purity of ultra-luxury automotive editorial design. It delivers a cinematic dark aesthetic defined by deep obsidian depths, luminous platinum surfaces, and ambient cold-spectrum luminescence. 

The aesthetic marries precision engineered minimalism with optical glassmorphism. It evokes calm authority, technical mastery, and effortless prestige. Every element balances industrial discipline with fluid elegance—commanding attention through disciplined composition, generous negative space, and meticulous hairline details rather than loud decoration.

## Colors

The palette is anchored in subterranean darks and luminous atmospheric highlights:

- **Background & Canvas (`#0A0A0C` to `#111115`):** Midnight obsidian tones that absorb visual noise and provide infinite depth for glass refraction.
- **Luminous Platinum / Chrome (`#CBD5E1`, `#F8FAFC`):** Precision metallic highlights used for key typography, hairline borders, and reflective edge highlights.
- **Cyan / Aerodynamic Teal (`#0DCDC0`):** Electric performance accent used sparingly for active states, high-priority interactions, telemetry markers, and subtle ambient back-glows.
- **Iridescent Silver-Blue (`#60A5FA`, `#38BDF8`):** Atmospheric secondary accents used for gradient sweeps, ambient glows, and state transitions.
- **Surface Translucencies:** Alpha-blended layers (`rgba(255, 255, 255, 0.03)` to `rgba(255, 255, 255, 0.08)`) over obsidian backdrops to construct physical weight without visual bulk.

## Typography

The type system blends the aerodynamic precision of **Space Grotesk** with the neutral, hyper-readable clarity of **Inter**.

- **Editorial Headlines (Space Grotesk):** Tight tracking (`-0.02em` to `-0.04em`), medium-to-semibold weights, and calibrated line heights create commanding, sculptural titles reminiscent of luxury automotive marques.
- **Narrative & Telemetry Body (Inter):** Generous line height and light weights (`300` and `400`) produce an airy, breathable cadence against deep black canvases.
- **Instrument Labels (Space Grotesk Caps):** Technical micro-copy, status meters, and telemetry indicators utilize uppercase Space Grotesk with expanded tracking (`0.15em`) for precise instrumentation aesthetics.

## Layout & Spacing

The layout is built on a 12-column fluid grid governed by lavish negative space and cinematic wide margins. 

- **Desktop (1440px+):** 12-column structure with `margin: 4rem` and `gutter: 2rem`. Content breathes freely, utilizing wide lateral margins to create a focused, widescreen viewing plane.
- **Tablet (768px - 1439px):** 8-column layout with `margin: 2.5rem` and `gutter: 1.5rem`.
- **Mobile (< 768px):** 4-column layout with `margin: 1.5rem` and `gutter: 1rem`. Glass panels stretch close to the edge while maintaining a rigid inner padding rhythm.
- **Spatial Rhythm:** Vertical spacing leans heavily into oversized gutters (`space-xl` and above) between thematic modules, counterbalanced by tight, micro-calibrated groupings (`space-xs` and `space-sm`) inside interactive glass modules.

## Elevation & Depth

Depth is rendered through physical light simulation, optical filtration, and cold chromatic emissions rather than heavy black drop shadows.

- **Glassmorphic Substrates:** Panels use `backdrop-filter: blur(24px) saturate(180%)` over subtle obsidian glass tinting (`rgba(17, 17, 21, 0.65)`).
- **Platinum Specular Rims:** Surfaces are defined by an ultra-thin 1px top-lit stroke (`border: 1px solid rgba(255, 255, 255, 0.12)`), with an internal gradient reflection fading to `rgba(255, 255, 255, 0.02)` at the bottom edge.
- **Ambient Chromatic Glows:** High-elevation or activated modules emit an ambient diffused glow using primary teal or iridescent blue (`box-shadow: 0 16px 40px -12px rgba(13, 205, 192, 0.15)`).
- **Layer Stacking:** Three core elevation planes:
  1. *Substrate 0 (Base Canvas):* Pure `#0A0A0C` obsidian with slow radial gradient luminescence.
  2. *Substrate 1 (Flow Cards & Decks):* Frosted translucent obsidian with micro-hairlines.
  3. *Substrate 2 (Overlays, Floating Cockpits & Modals):* Elevated glass with specular outer rim and cyan ambient falloff.

## Shapes

The design uses a refined radius scale (`roundedness: 2`, base 0.5rem / 8px up to 1.5rem / 24px) echoing aerodynamic coachwork:

- **Panels & Cards (`rounded-xl` / 24px):** Generous, smooth curvature evoking wind-tunnel sculpted edges.
- **Controls & Buttons (`rounded-lg` / 16px):** Ergonomic, tactile corners that fit thumb and cursor geometries.
- **Micro Badges & Chips (`rounded-md` / 8px):** Precision-cut corners for instrumentation readouts.
- **Pill overrides (`full-radius`):** Reserved strictly for primary floating action pods and audio/telemetry toggles.

## Components

### Buttons
- **Primary Action:** Solid platinum or vibrant aero teal base (`#0DCDC0`) with dark obsidian typography (`#0A0A0C`). Hover initiates an internal luminous shimmer with subtle outer bloom (`box-shadow: 0 0 24px rgba(13, 205, 192, 0.35)`).
- **Secondary (Glass Cockpit):** Translucent fill (`rgba(255, 255, 255, 0.05)`), 1px platinum border (`rgba(203, 213, 225, 0.2)`), crisp white text. Hover transitions background to `rgba(255, 255, 255, 0.1)` and border to cyan.
- **Ghost Action:** Pure text with Space Grotesk caps, animated baseline hairline expander on hover.

### Translucent Cards
- **Construction:** Frosted glass backing (`rgba(17, 17, 21, 0.6)`), 20px blur, and top-weighted linear border gradient (`rgba(255,255,255,0.15)` to `rgba(255,255,255,0.02)`).
- **Interaction:** Hover triggers a silky vertical rise (`transform: translateY(-4px)`) and activates an iridescent silver-blue edge highlight.

### Chips & Telemetry Tags
- Compact height (28px), uppercase Space Grotesk tracking (`0.15em`), dark translucent backing with 1px hairline border.
- Active state displays a micro glowing cyan status pip (`4px`) with ambient pulse.

### Inputs & Fields
- Dark recessed substrate (`#0F0F13`), 1px muted border (`rgba(255, 255, 255, 0.08)`).
- Focus state eliminates standard browser rings, replacing them with a crisp 1px aero teal stroke and soft inner platinum wash.

### Checkboxes & Radios
- Sharp-curved square or circle geometry, dark interior. Checked state reveals an electric cyan fill with pure obsidian core icon.

### Additional Signature Component: Cockpit Telemetry Slider
- Continuous hairline rail in chrome-tinted zinc (`rgba(255, 255, 255, 0.15)`) with an iridescent blue active fill and an illuminated floating glass thumb with a glowing cyan center.